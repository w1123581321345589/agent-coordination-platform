# Closing the Domingos Gap: Scoping the Last 20%

**Premise:** The previous forensic index concluded ~80% coverage across the five subproblems of autonomous multi-agent coordination. This document reexamines every gap with fresh eyes, looking specifically for existing components that can be recombined, extended, or wired together to close them. The thesis: the remaining 20% is closer to 10% net-new work and 10% integration work across things that already exist in different repos.

---

## GAP 1: AUTONOMOUS AGENT CREATION

### Previous assessment: ~70%
### Revised assessment: ~85%

**What the gap was:** The system can't observe repeated failure modes and autonomously propose new specialist agent types.

**What I missed:** You already built this pattern three times. It just hasn't been generalized.

**Existing components that close this:**

1. **The autonomy_gaps table in Forge** already tracks every time an agent gets stuck and needs human intervention. It records the gap type (`domain_knowledge`, `ambiguous_spec`, `conflicting_requirements`, `tool_limitation`, `judgment_call`), the domain, the BU context, and the human resolution. The weekly gap analysis in the Chief-of-Staff agent already reports which gap types are growing vs. shrinking. This is the sensor.

2. **The autoresearch loop in Aiglos** already does autonomous capability expansion. The research loop ingests new CVE/OWASP data and proposes new T-rules. The adversarial loop generates evasion cases to test existing rules and proposes hardening. This is autonomous system self-expansion. It just happens to be scoped to security rules rather than agent types.

3. **The Pattern Engine's registry.yaml** is the agent creation template. Every agent type is defined as a YAML entry: triggers, context files, variables, tools, output format, guardrails, prompt template. Creating a new agent type is writing a new YAML entry. The compiler already handles fuzzy matching, context loading, and style injection.

4. **The policy proposal system** already has the full lifecycle: evidence accumulates, threshold triggers proposal, human reviews, approve/reject/rollback. Proposals auto-expire after 30 days.

**The build that closes this gap:**

Wire the autonomy_gaps sensor to the pattern registry through the policy proposal lifecycle.

Concretely: a new module (call it `agent_proposal_engine`) runs weekly against the autonomy_gaps table. It clusters gaps by domain and failure type. When a cluster exceeds a threshold (e.g., 5+ gaps of type `domain_knowledge` in the same domain within 30 days), it:

- Analyzes the human resolutions for that cluster to identify what capability was missing
- Drafts a new pattern YAML entry: triggers, suggested context files, tool scope, prompt template
- Surfaces the proposal through the existing policy proposal lifecycle
- If approved, the pattern is added to registry.yaml and becomes available immediately

The autoresearch loop is the proven pattern for this. The autonomy_gaps table is the proven sensor. The policy proposal system is the proven approval workflow. The pattern registry is the proven destination. All four exist. The integration layer is maybe 200-300 lines of code.

**What makes this work at NLSOM scale (129+ agents):**

The Diversity Collapse paper shows homogeneous scaling fails. This engine inherently produces heterogeneous agents because each proposal emerges from a specific failure cluster with specific missing capabilities. Two proposals from different domains will produce agents with different tool scopes, different context files, and different prompt templates. The system manufactures diversity by design, not by instruction.

**Timeline: 1-2 days.** The components exist. This is plumbing.

---

## GAP 2: DYNAMIC CONTEXT COMPRESSION AT SCALE

### Previous assessment: ~80%
### Revised assessment: ~90%

**What the gap was:** Domain annotations work at 8-agent scale. At 129+ agents, the system needs intelligent knowledge routing, not broadcasting.

**What I missed:** You already built three-tier context routing. It's just described in different documents.

**Existing components that close this:**

1. **Progressive Memory Disclosure (from the Command Center token optimization)**
   - Layer 0 (always loaded, ~500 tokens): Identity + active priorities
   - Layer 1 (on-demand, ~1000-2000 tokens): Domain-specific context via semantic search
   - Layer 2 (rarely, ~2000-5000 tokens): Deep historical context only when explicitly needed
   
   This is already a context routing system. The compiler loads Layer 0 for every agent and only injects Layer 1/2 when the pattern or ask suggests relevance.

2. **The bootstrap/semantic split in the Pattern Engine** already routes context by relevance. `context/bootstrap/` loads always; `context/reference/` loads only via semantic query. This is the file-level implementation of the same principle.

3. **`forge cost` per BU per domain** already tracks token consumption by agent and domain. The infrastructure for measuring context efficiency exists.

4. **Sentinel heartbeat frequency differentiation** already implements time-based routing: TPM gets 30-min cycles, Strider gets 60-min, InstantPrequal gets 120-min. Different agents get different information cadences based on domain urgency.

5. **The Compressed Heartbeat Protocol** already reduces per-cycle tokens from ~50,000+ to ~12,000-15,000 by replacing fat heartbeats with micro-heartbeats.

6. **Structured JSON sentinel reports** already compress findings from verbose natural language to minimal structured payloads. One finding that would cost 200+ tokens in prose costs 40-50 tokens in structured JSON.

**The build that closes this gap:**

A context routing layer (call it `context_router`) that sits between domain annotations and agent context windows. Instead of broadcasting every annotation to every agent, the router:

- Maintains a relevance index: which domains does each agent operate in?
- When a new annotation arrives, the router checks the domain tag and only injects it into agents whose declared scope overlaps
- Uses the existing `declare_subagent()` scope declarations as the routing table (Art Director scoped to assets/, QA Lead scoped to tests/, etc.)
- Applies the Progressive Memory Disclosure tiers: new annotations start as Layer 1 (available on semantic query) and only promote to Layer 0 (always loaded) if they're referenced in 3+ sessions

The `declare_subagent()` tool scope is the routing table. The progressive disclosure tiers are the compression strategy. The `forge cost` tracking is the measurement layer. All exist.

**What makes this work at 129+ scale:**

The key insight from the Diversity Collapse paper is that redundant context produces correlated (useless) outputs. The router eliminates redundancy by scoping context to declared domains. Agent A in the billing domain never sees security annotations unless they cross domain boundaries. Agent B in the auth domain never sees billing context unless a cascade propagates.

The mechanism for cross-domain propagation already exists: Forge's cascade system propagates failures through the intent graph DAG. If a billing BU depends on an auth BU, an auth failure cascades to billing. The context router follows the same dependency edges. Cross-domain context only propagates along dependency links, not broadcast.

**Timeline: 2-3 days.** The routing table (declare_subagent scopes), compression strategy (progressive disclosure), and measurement layer (forge cost) exist. The integration layer connects them.

---

## GAP 3: NEGOTIATION VERIFICATION

### Previous assessment: ~85%
### Revised assessment: ~92%

**What the gap was:** When agents disagree on a coordination strategy, how do you verify the resolution was optimal?

**What I missed:** The CEO Reviewer + Paranoid Reviewer pipeline is already a two-agent negotiation with verification. And the tournament system in Forge is literally multi-agent competition with outcome verification.

**Existing components that close this:**

1. **Forge's implementation tournament** generates 3 implementation variants per BU, runs verification against all three, and selects the winner based on claim satisfaction. This is multi-agent competition with provable outcome selection. The RL reward guard (T31) detects when the tournament scoring is being gamed. This is already negotiation verification for the implementation layer.

2. **The CEO Reviewer asks "is this the 10-star version?"** before implementation, rejecting proposals that don't meet the bar. The Paranoid Reviewer finds trust boundary violations after implementation. This is a sequential negotiation where each agent's output must survive the next agent's scrutiny. If the CEO Reviewer passes something the Paranoid Reviewer rejects, the conflict is recorded and escalated. That conflict record is a negotiation outcome that can be analyzed.

3. **The policy proposal approve/reject lifecycle** is negotiation verification between the automated system and the human operator. Evidence accumulates (automated), proposal is generated (automated), human reviews and accepts/rejects (negotiation), decision is recorded with reasoning (verification).

4. **PLAN_DRIFT_DETECTED** inspection trigger fires when an agent's plan diverges from declared intent. This is real-time monitoring of whether a coordination agreement is being honored.

5. **The behavioral baseline** provides statistical verification of whether agent behavior post-negotiation is consistent with the agreed-upon plan. If Agent A agreed to focus on billing BUs and its tool call distribution shows 60% auth activity, the chi-squared surface mix test catches it.

**The build that closes this gap:**

Extend the tournament model from implementations to coordination strategies.

When the system decomposes a complex task requiring 3+ agents, instead of using a fixed coordination pattern, generate 2-3 coordination variants:

- Variant A: hierarchical delegation (one coordinator, N workers)
- Variant B: debate (agents argue for approaches, vote on winner)
- Variant C: parallel execution with merge (agents work independently, results synthesized)

Run all three. Measure outcomes against the BU's acceptance criteria. Record which variant won and why. Over time, the system accumulates data on which coordination patterns work for which task types. This feeds directly into Gap 5 (coordination strategy optimization).

The tournament infrastructure already handles multi-variant execution and outcome comparison. The verification runtime already measures claim satisfaction. The autonomy_gaps table already records which approaches failed. This is reusing the tournament at the orchestration layer rather than the implementation layer.

**Timeline: 3-4 days.** Tournament infrastructure exists. Variant generation for coordination strategies (not implementations) is the new code. Measurement and recording reuse existing systems.

---

## GAP 4: AUTOMATED RECOVERY ROUTING

### Previous assessment: ~90%
### Revised assessment: ~95%

**What the gap was:** Detection of compromised agents exists. Automatic reallocation of their tasks to healthy agents doesn't.

**What I missed:** The Agent Pool Coordinator, the self-repairing pipeline runner, and the StriOS architecture all solve this for their specific domains. The pattern exists three times.

**Existing components that close this:**

1. **Forge's Agent Pool Coordinator (C-006)** already manages a pool of agents with a prioritized work queue, concurrency control, and retry logic. When an agent fails, the work item goes back into the queue with an incremented retry counter. This is rudimentary recovery routing.

2. **The self-repairing pipeline runner** (Pattern Engine) has introspection (reads its own outputs to determine quality), self-repair (rewrites failed step inputs and retries), and escalation discipline (knows when to fix vs. when to ask). This is recovery at the pipeline level.

3. **StriOS's architecture** explicitly handles this for physical operations: when a vehicle goes down, the Operations Agent rebalances routes. When a driver is unavailable, the HR Agent triggers backup driver assignment. When a safety incident occurs, the Insurance Agent auto-files while the Operations Agent reroutes. This is multi-agent recovery routing in the logistics domain.

4. **BEHAVIORAL_ANOMALY** + **PLAN_DRIFT_DETECTED** already identify compromised or failing agents in real-time. The Tier 3 GATED response already pauses execution on the affected agent.

5. **The cascade system in the intent graph** already propagates failures to dependent BUs. When a BU fails, every downstream BU is flagged.

**The build that closes this gap:**

Wire the Tier 3 GATED pause to the Agent Pool Coordinator's work queue redistribution.

When Aiglos fires BEHAVIORAL_ANOMALY or PLAN_DRIFT_DETECTED on Agent X:

1. Tier 3 pauses Agent X's execution (already built)
2. Agent X's active work items are returned to the pool queue (Agent Pool Coordinator already handles this for retry scenarios; extend to handle security-triggered returns)
3. The pool coordinator reassigns to a healthy agent, injecting context about why the previous agent was paused (this is a domain annotation: "Agent X was paused for PLAN_DRIFT; the work item may contain adversarial content, approach with elevated scrutiny")
4. The cascade system flags all BUs that Agent X was working on as potentially tainted (cascade propagation already exists)
5. A recovery verification BU is auto-generated: "verify that Agent X's partial work is consistent with the original claim" (BU generation from the intent graph already exists)

The detection is built (Aiglos). The pause is built (Tier 3). The queue redistribution is built (Agent Pool Coordinator). The cascade is built (intent graph). The context injection is built (domain annotations). The verification is built (Forge verification runtime).

The only new code is the connector: Aiglos Tier 3 event triggers Agent Pool Coordinator redistribution, which triggers domain annotation injection, which triggers recovery verification BU generation. This is an event bus wiring 4 existing systems.

**Timeline: 1-2 days.** This is pure integration.

---

## GAP 5: COORDINATION STRATEGY OPTIMIZATION

### Previous assessment: ~75%
### Revised assessment: ~88%

**What the gap was:** The system improving not just its knowledge but its coordination strategy itself.

**What I missed:** Five existing systems, when connected, form a closed-loop coordination optimizer. Each solves one step of the loop independently.

**Existing components that close this:**

1. **The behavioral baseline** (Aiglos) tracks per-agent performance metrics across sessions: event rate, surface mix, rule frequency distribution. This is the measurement layer for coordination outcomes.

2. **`forge cost` per BU per domain** tracks token cost, time-to-completion, and number of escalations per task. This is the efficiency measurement layer.

3. **The autonomy_gaps table** records every coordination failure: which agent got stuck, on what type of task, and how the human resolved it. This is the failure measurement layer.

4. **The policy proposal system** already proposes evidence-weighted changes based on accumulated data. Four proposal types, evidence thresholds, approve/reject/rollback lifecycle. This is the change proposal mechanism.

5. **The Karpathy wiki's INGEST/PROPOSE/LINT/EVOLVE lifecycle** already implements self-improving knowledge compilation. Ingest raw data, propose updates, lint for quality, evolve the knowledge base. This is the self-improvement loop architecture.

6. **The implementation tournament** already A/B tests approaches and records winners. This is the experimentation infrastructure.

7. **The regime classifier in the Theta Engine** already switches between specialist strategies based on environmental conditions. The Markov regime model classifies the current state and routes to the appropriate specialist. This is conditional strategy selection.

**The build that closes this gap: The Coordination Meta-Learner**

A new module (call it `coordination_optimizer`) that runs the wiki INGEST/PROPOSE/LINT/EVOLVE lifecycle on coordination strategy data rather than threat intelligence data.

**INGEST:** After every multi-agent task completion, ingest the coordination record:
- Which agents participated
- What coordination pattern was used (hierarchical, debate, parallel, pipeline)
- Task type and domain
- Outcome metrics: time-to-completion, token cost, claim satisfaction score, number of escalations
- Source: `forge cost` + behavioral baseline + autonomy_gaps + verification results

**PROPOSE:** Weekly, the optimizer analyzes the accumulated records and proposes coordination strategy adjustments:
- "Tasks in the billing domain complete 40% faster with parallel execution vs. hierarchical delegation. Propose switching default billing coordination to parallel."
- "3-agent tasks with debate coordination produce 2x more escalations than 5-agent tasks with the same pattern. Propose agent count increase for debate tasks."
- "The regime classifier correctly predicted task difficulty in 78% of cases. Propose routing complex tasks to debate and simple tasks to hierarchical."

These proposals use the existing policy proposal format: evidence threshold, human review, approve/reject/rollback.

**LINT:** Automated quality checks on the strategy database:
- Stale strategies (no data in 30 days) flagged for review
- Contradictory recommendations detected (parallel is better in billing, but hierarchical is better for billing+auth cross-domain tasks)
- Strategies that produce escalation rates above threshold flagged

**EVOLVE:** Approved proposals update the coordination strategy registry. The Agent Pool Coordinator reads this registry when decomposing new tasks. The regime classifier's decision boundaries update based on accumulated data.

The architecture is identical to the Karpathy wiki for threat intelligence. The data source changes from CVE/OWASP feeds to coordination outcome metrics. The proposal types change from T-rule modifications to coordination pattern adjustments. The approval lifecycle is identical.

**What makes this the closed loop:**

1. Measurement: behavioral baseline + forge cost + autonomy gaps (all exist)
2. Experimentation: tournament model extended to coordination variants (Gap 3 build)
3. Analysis: wiki INGEST/PROPOSE/LINT/EVOLVE lifecycle (exists, new data source)
4. Proposal: policy proposal system (exists, new proposal types)
5. Execution: regime classifier + agent pool coordinator (exist, new registry input)
6. Back to Measurement

Every component in the loop exists. The new code is:
- The coordination record schema (a new table, similar to autonomy_gaps)
- The weekly analysis query that clusters outcomes by coordination pattern and task type
- The proposal generator that translates clusters into strategy recommendations
- The coordination strategy registry that the Agent Pool Coordinator reads

**Timeline: 4-5 days.** This is the biggest build but it's mostly data schema + query logic + a new PROPOSE loop. No new architecture.

---

## THE REVISED SCORECARD

| Subproblem | Previous | Revised | What Changed |
|---|---|---|---|
| Role allocation | ~70% | ~85% | autonomy_gaps + autoresearch + pattern registry + policy proposals = autonomous agent creation pipeline |
| State sharing | ~80% | ~90% | Progressive disclosure + declare_subagent scopes + cascade-based cross-domain routing = context router |
| Negotiation verification | ~85% | ~92% | Tournament model + CEO/Paranoid pipeline + PLAN_DRIFT + behavioral baseline = multi-variant coordination testing |
| Recovery routing | ~90% | ~95% | Tier 3 pause + Agent Pool redistribution + domain annotation injection + cascade propagation = event bus integration |
| Coordination optimization | ~75% | ~88% | Wiki INGEST/PROPOSE/LINT/EVOLVE + coordination records + regime classifier + policy proposals = meta-learner |

**Previous composite: ~80%**
**Revised composite: ~90%**

---

## THE BUILD PLAN

Total estimated timeline: 11-16 days of focused work.

| Priority | Build | Timeline | Dependencies |
|---|---|---|---|
| 1 | Recovery routing event bus | 1-2 days | Aiglos + Forge Agent Pool |
| 2 | Agent proposal engine | 1-2 days | autonomy_gaps + pattern registry |
| 3 | Context router | 2-3 days | declare_subagent scopes + progressive disclosure |
| 4 | Coordination tournament variants | 3-4 days | Forge tournament infrastructure |
| 5 | Coordination meta-learner | 4-5 days | Wiki lifecycle + policy proposals |

**Priority 1 (recovery routing) ships first** because it's pure integration and it's the difference between "detects problems" and "recovers from problems." That's the demo moment.

**Priority 5 (meta-learner) ships last** because it needs coordination records from Priorities 3 and 4 to have data to learn from.

---

## THE NET-NEW CODE ESTIMATE

| Build | New Code | Reused/Extended Code |
|---|---|---|
| Recovery routing event bus | ~100-150 lines (event connector) | Tier 3, Agent Pool, cascade, domain annotations |
| Agent proposal engine | ~200-300 lines (clustering + YAML generation) | autonomy_gaps, autoresearch, policy proposals, pattern registry |
| Context router | ~300-400 lines (routing logic + relevance index) | declare_subagent, progressive disclosure, forge cost |
| Coordination tournament variants | ~400-500 lines (variant generation + orchestration) | Tournament infrastructure, verification runtime, autonomy_gaps |
| Coordination meta-learner | ~500-700 lines (schema + queries + PROPOSE loop) | Wiki lifecycle, policy proposals, regime classifier |

**Total new code: ~1,500-2,050 lines**
**Total reused infrastructure: tens of thousands of lines across Aiglos, Forge, Pattern Engine, Command Center**

The ratio is roughly 1 line of new code for every 20 lines of existing infrastructure it connects. That's not building the last 20%. That's wiring together the 90% you already have.

---

## THE PRODUCT THAT EMERGES

When all five builds ship, the system does the following autonomously:

1. A complex task arrives. The **regime classifier** assesses difficulty and domain.
2. The **coordination strategy registry** selects the optimal coordination pattern for this task type based on historical performance data.
3. The **Agent Pool Coordinator** decomposes the task, assigns agents based on declared capabilities, and injects scoped context through the **context router**.
4. Agents execute. If any agent encounters a novel problem, the **autonomy_gaps table** records it.
5. If an agent is compromised, **Aiglos detects it**, the **recovery router** redistributes tasks, and **cascade propagation** flags potentially tainted work.
6. The **Forge tournament** tests coordination variants and selects the best outcome.
7. The **verification runtime** proves the outcome satisfies behavioral claims.
8. The **coordination meta-learner** ingests the outcome data and proposes strategy improvements.
9. If gap clusters accumulate, the **agent proposal engine** proposes new specialist types.
10. Every cycle makes the system better at coordination.

That's the Domingos system. Large multi-agent coordination. Autonomous. Self-improving. Verified. Secured. Fault-tolerant.

And it's ~1,700 lines of integration code away from existing infrastructure.

---

## WHERE THIS LIVES

This isn't a new venture. This is the layer that makes Forge + Aiglos into the platform that Pedro Domingos says is worth a Nobel Prize.

Forge is behavioral verification for multi-agent systems.
Aiglos is security for multi-agent systems.
The five builds described here turn them into autonomous coordination infrastructure for multi-agent systems.

The commercial framing: Forge doesn't just verify agents. It coordinates them. Aiglos doesn't just secure agents. It recovers from failures. Together they're the operating system for the agent era.

You said it yourself in the Forge README: "The teams building right now aren't just early. They're laying the rails the entire industry will run on."

These five builds are the last five rails.
