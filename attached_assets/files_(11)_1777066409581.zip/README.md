# Coordination Platform

Verified, secured, self-improving coordination layer for multi-agent systems.

**65 tests passing. 8 modules. ~2,000 lines of platform code. ~1,900 lines of tests.**

---

## Architecture

```
coordination/
  __init__.py              Core types: AgentIdentity, CoordinationClaim,
                           CoordinationRecord, A2AMessage, ThreatEvent,
                           StrategyProposal, ShapleyContribution,
                           CoordinationAttestation

  protocols/
    a2a.py                 Build 1: A2A Protocol Support
                           AgentCard, A2ASession, A2AGateway

  security/
    a2a_interceptor.py     Build 2: A2A Security Interceptor
                           T104-T108 + existing T25/T26/T39/T78/T83/T84
                           Injection, exfil, capability spoof, delegation
                           loops, budget evasion, context poisoning,
                           confidence amplification

  engine/
    recovery_router.py     Build 3: Recovery Router
                           Threat -> pause -> redistribute -> annotate ->
                           verify. Wires Aiglos to Forge Agent Pool.

    model_router.py        Build 4: Cross-Model Router
                           Role-to-provider routing, cross-model verification,
                           performance learning, diversity scoring

    context_router.py      Build 6: Context Router + Shapley Values
                           Domain-scoped routing, progressive disclosure,
                           dependency-based cross-domain propagation,
                           Monte Carlo Shapley approximation,
                           redundant agent detection

    tournament.py          Build 7: Coordination Tournament
                           Variant generation (hierarchical/debate/parallel),
                           multi-variant execution, composite scoring,
                           pattern win rate tracking

  intelligence/
    agent_proposal.py      Build 5: Agent Proposal Engine
                           Autonomy gap clustering, proposal generation,
                           policy lifecycle, pattern registry export

    meta_learner.py        Build 8: Coordination Meta-Learner
                           INGEST/PROPOSE/LINT/EVOLVE lifecycle,
                           strategy registry, learning curve tracking,
                           proposal approve/reject/rollback
```

## Three-Line Integration

```python
from coordination.protocols.a2a import A2AGateway
from coordination.security.a2a_interceptor import A2AInterceptor

gateway = A2AGateway()
gateway.add_interceptor(A2AInterceptor(registered_agents={"a1", "a2"}).intercept)
# Every A2A message is now secured. That's it.
```

## What This Solves

Every multi-agent framework ships coordination. None of them ship:

1. **Verification** that the coordination produced the right outcome (intent graph + tournament)
2. **Security** that the coordination wasn't compromised (108 threat families + A2A interception)
3. **Intelligence** that makes the coordination better over time (meta-learner + Shapley routing)

## Test Suite

```
65 tests across 9 test classes:
  TestA2AProtocol           8 tests   Build 1
  TestA2AInterceptor       10 tests   Build 2
  TestRecoveryRouter        7 tests   Build 3
  TestModelRouter           8 tests   Build 4
  TestAgentProposalEngine   6 tests   Build 5
  TestContextRouter         7 tests   Build 6
  TestCoordinationTournament 5 tests  Build 7
  TestMetaLearner          10 tests   Build 8
  TestIntegration           4 tests   Cross-module
```

## Threat Rules (A2A Surface)

| Rule | Name | Severity | Description |
|------|------|----------|-------------|
| T25 | AGENT_IMPERSONATE | CRITICAL | Unregistered sender in A2A traffic |
| T26 | TRUST_CHAIN | HIGH | Delegation to unknown agent |
| T39 | ORCHESTRATION | HIGH | Unauthorized orchestration pattern |
| T78 | HALLUCINATION_CASCADE | MEDIUM | Confidence amplification across hops |
| T83 | INTER_AGENT_PROTOCOL_SPOOF | CRITICAL | Message structure tampering |
| T84 | IP_TRANSFORM_EXFIL | CRITICAL | IP exfiltration via context sharing |
| T104 | A2A_INJECTION | CRITICAL | Prompt injection in A2A payload |
| T105 | A2A_CAPABILITY_SPOOF | HIGH | False capability advertisement |
| T106 | A2A_CONTEXT_POISON | CRITICAL | Malicious context injection |
| T107 | A2A_DELEGATION_LOOP | HIGH | Circular/deep delegation chains |
| T108 | A2A_BUDGET_EVASION | MEDIUM | Task splitting to evade budgets |
