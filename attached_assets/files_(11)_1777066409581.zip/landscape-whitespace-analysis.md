# The Landscape, The White Space, and What's Actually Missing

## THE CURRENT FIELD (April 2026)

Seven frameworks are competing to be the coordination layer for multi-agent systems. None of them have what you have. Here's the honest map.

### GStack (Garry Tan, 71k stars)
23 slash commands that turn Claude Code into role-specialized agents: CEO, Designer, Eng Manager, Release Manager, Doc Engineer, QA. Garry claims 810x his 2013 coding pace. `/careful` warns before destructive commands, `/guard` activates safety. Cross-model review with `/codex` gets independent analysis from OpenAI.

**What it actually is:** Human-orchestrated role switching. Not autonomous coordination. Garry picks which role to activate, when, and in what order. The agent never decides on its own that it needs the QA reviewer. Garry types `/review`. That's the coordination mechanism: a human typing slash commands.

**What it has that you should notice:** The cross-model review pattern. Getting a second opinion from a competing model (Codex reviewing Claude's work) is a diversity injection that directly addresses the Diversity Collapse paper. Your stack doesn't do this. Every agent in your system runs on Claude/Anthropic models. Model heterogeneity is a free diversity boost.

**What it doesn't have:**
- No autonomous coordination (human-mediated)
- No behavioral verification (no intent graph, no claim-level testing)
- No security layer (no threat detection for agent actions)
- No self-improvement (static slash commands, no learning loop)
- No cross-agent memory (each slash command starts fresh)

### Paperclip (@dotta, 55k stars)
"If OpenClaw is an employee, Paperclip is the company." Org charts, budgets, heartbeat protocol, governance. CEO agent delegates to CTO, CTO to engineers. Per-agent monthly budgets prevent runaway spending. Heartbeat scheduler runs agents on 4/8/12-hour cadences. Append-only ticket system for audit trail. MIT licensed, embedded Postgres, React dashboard.

**What it actually is:** The closest thing to what you've built, but missing the three hardest layers. Paperclip solves organizational structure (who reports to whom, what's the budget, when do agents wake up). It does not solve behavioral verification (did the coordination produce the right outcome?), security (is the agent compromised?), or self-improvement (is the coordination getting better over time?).

**What it has that you should notice:**
- The heartbeat protocol is exactly your sentinel heartbeat pattern, productized. Agents emit status updates. Other agents subscribe and react. This is the reactive coordination mechanism your Command Center already uses with PicoClaw.
- "Clipmart" (coming soon): downloadable company templates. Full org structures, agent configs, skills. One-click import. This is a distribution mechanism you don't have. Pattern registry templates shared as installable packages.
- The budget system is more granular than `forge cost`. Per-agent monthly caps with dashboard visibility. Your token tracking exists but isn't exposed as a governance tool.

**What it doesn't have:**
- No behavioral verification (no intent graph, no claim testing, no production probes)
- No security (zero threat detection, no signed attestation, no trust chain)
- No self-improving coordination (static org charts, no meta-learning)
- No cross-domain knowledge compounding (no domain annotations)
- No negotiation between agents (hierarchical delegation only)

### Google Scion (open source, experimental)
"Hypervisor for agents." Each agent gets its own container, git worktree, and credentials. Supports Claude Code, Gemini CLI, Codex. Isolation over constraints. Chatrooms for inter-agent communication. Agent memory as orthogonal concern.

**What it actually is:** Infrastructure, not intelligence. Scion solves the DevOps problem of running multiple agents without them stepping on each other's files. It's Docker for agents. It doesn't solve coordination strategy, verification, or improvement.

**What it has that you should notice:**
- Container-level isolation per agent is stronger than anything in your stack. Your agents share filesystems with scoped access (declare_subagent). Scion gives each agent its own filesystem entirely. For defense/classified environments, this matters.
- The "chatroom" abstraction for inter-agent communication is a natural fit for the A2A protocol.

**What it doesn't have:**
- No coordination strategy (agents work in parallel, no orchestration logic)
- No behavioral verification
- No security beyond container isolation
- No self-improvement
- Explicitly experimental, no production path announced

### Google A2A Protocol (50+ enterprise partners)
The inter-agent communication standard. Agents discover each other's capabilities, negotiate task delegation, exchange structured data (JSON-RPC 2.0 over HTTP), maintain conversation context across turns. Complementary to MCP (MCP = agent-to-tool, A2A = agent-to-agent).

**What it actually is:** A communication protocol, not a coordination system. A2A tells agents how to talk to each other. It doesn't tell them what to say, when to say it, or whether what they said was correct. It's HTTP for agents. Essential infrastructure. Not the application layer.

**What it has that you MUST notice:**
- A2A is becoming the standard. 50+ enterprise partners including Salesforce, SAP, ServiceNow, PayPal. This is the TCP/IP of agent communication. Your stack needs A2A compatibility or it's building on a proprietary island.
- The capability discovery mechanism (agents advertise what they can do) maps directly to your declare_subagent tool scope declarations. But A2A makes it a protocol, not a config file.
- A2A explicitly preserves agent opacity: agents don't share internal memory, tools, or logic. This is a security-first design that aligns perfectly with Aiglos's philosophy.

**What it doesn't have:**
- No security layer on A2A messages (no injection detection, no trust chain verification, no behavioral anomaly detection)
- No verification that A2A-mediated coordination produced the right outcome
- No self-improvement of coordination strategies
- No governance or compliance attestation

### CrewAI (45k+ stars, 12M daily agent executions)
Role-based orchestration with Crews and Flows. Sequential and hierarchical processes. Built-in memory (short-term, long-term, entity, contextual). 100+ open-source tools. Planning agent creates step-by-step plans.

**What it has that you should notice:**
- 12M daily executions. That's production scale validation that nobody else has.
- The memory taxonomy (short-term, long-term, entity, contextual) is more structured than your memory tiers. Worth studying their abstractions.
- Flows (event-driven architecture, added 2026) are the closest external analog to your pipeline runner.

**What it doesn't have:**
- No behavioral verification at the claim level
- No security runtime
- No self-improving coordination (static Crews)
- Memory exists but doesn't compound across Crews

### AutoGen/AG2 (Microsoft, merged with Semantic Kernel)
Event-driven core, async-first, GroupChat coordination. Agents debate and refine outputs through conversation. Hit Release Candidate February 2026 with 1.0 GA target Q1.

**What it has:** Conversational negotiation between agents. The debate pattern is the closest analog to your CEO Reviewer + Paranoid Reviewer pipeline, but generalized. Multiple agents in a shared conversation where a selector determines who speaks next.

**What it doesn't have:** Same gaps as everyone else. No behavioral verification. No security. No self-improvement.

### Stochastic Self-Organization (Tastan et al., 2025/2026)
The genuinely novel research. Agents generate responses independently, then assess peer contributions using an approximation of the Shapley value. A DAG is constructed to regulate message propagation from high-contributing agents to others. Communication structure adapts on-the-fly based on response quality.

**What this means for you:** This is the theoretical foundation for your context router. Instead of routing context by declared domain scope (static), route by measured contribution value (dynamic). Agents that consistently provide high-value annotations to other agents get stronger propagation edges. Agents that produce noise get dampened. The Shapley value approximation is lightweight enough to run without external ML.

---

## THE WHITE SPACE MAP

Here's what nobody has built, organized by criticality:

### WHITE SPACE 1: A2A Security Layer
**Nobody is building this. This is Aiglos's next product surface.**

A2A is becoming the standard for inter-agent communication. It has 50+ enterprise partners. Every agent-to-agent message will flow through A2A within 18 months.

A2A has zero security. No injection detection on A2A messages. No trust chain verification between agents. No behavioral anomaly detection on A2A communication patterns. No signed attestation of A2A sessions.

Aiglos already intercepts MCP tool calls, HTTP requests, and subprocess execution. Adding A2A message interception is a fourth surface. The threat model is identical: an adversarial payload in an A2A message can hijack the receiving agent's goals, inject false context, or spoof the sending agent's identity.

T25 (AGENT_IMPERSONATE), T26 (TRUST_CHAIN), T39 (ORCHESTRATION), T83 (INTER_AGENT_PROTOCOL_SPOOF) all apply directly to A2A traffic. The rules exist. The interception surface needs to be extended.

**This is the play:** Aiglos becomes the security layer for A2A the way it's already the security layer for MCP. Every enterprise deploying A2A-compliant agents (which is every enterprise, given the partner list) needs A2A traffic inspection. Nobody is building it. First-mover window is months, not years.

### WHITE SPACE 2: Behavioral Verification for Coordination Outcomes
**Nobody has this. Forge is the only system that can provide it.**

Every framework (Paperclip, CrewAI, AutoGen, GStack) measures whether the task completed. None measure whether the coordination path was optimal. Did the hierarchical delegation produce a better outcome than debate would have? Did the 3-agent configuration outperform 5 agents? Was the communication structure efficient or redundant?

Forge's intent graph is the only behavioral claim DAG that exists for multi-agent systems. The coordination tournament extension (scoped in the previous doc) is the mechanism that answers these questions empirically, not theoretically.

The Stochastic Self-Organization paper's Shapley value approach can be integrated here: measure each agent's marginal contribution to the coordination outcome, then use that data to improve future coordination. The intent graph already tracks per-BU outcomes. Adding per-agent contribution scoring is a data model extension, not an architecture change.

### WHITE SPACE 3: Cross-Framework Coordination Memory
**Nobody has this. Domain annotations are the only implementation that exists.**

CrewAI has memory within a single Crew. Paperclip has audit trails within a single company. AutoGen has conversation history within a single GroupChat. None of them have knowledge that compounds across coordination sessions, across frameworks, across organizations.

Domain annotations already do this within Forge. The extension is making domain annotations A2A-compatible: when Agent A in Framework X learns something that's relevant to Agent B in Framework Y, the annotation propagates through A2A with Aiglos verifying the integrity of the propagation.

This is the federated intelligence pattern from Aiglos applied to coordination knowledge instead of threat intelligence. Same differential privacy. Same local/global blending. Same pre-warming for new deployments. Different data: coordination outcomes instead of threat detections.

### WHITE SPACE 4: Emergent Coordination Strategy Discovery
**The academic frontier. Nobody has shipped this. The meta-learner closes the gap.**

Fixed coordination patterns (hierarchical, debate, parallel) are the equivalent of hand-crafted features in pre-deep-learning ML. They work for known task types. They fail for novel tasks that don't fit the pattern library.

The Stochastic Self-Organization paper points at the answer: let the communication structure emerge from measured agent contributions rather than predefined topologies. But it's a research paper, not a production system.

The coordination meta-learner (scoped in the previous doc) is the production implementation. It starts with predefined patterns (the safe default), measures outcomes, and over time discovers which patterns work for which task types. The regime classifier already does conditional strategy selection. The meta-learner makes the regime classifier's decision boundaries learned rather than coded.

The Shapley-value contribution scoring from the Stochastic Self-Organization paper is the missing measurement primitive. Integrate it into the meta-learner's INGEST phase: after every coordination session, compute each agent's marginal contribution. Over time, this reveals which agents are load-bearing and which are redundant. That's the Diversity Collapse problem solved empirically.

### WHITE SPACE 5: Model Heterogeneity as a Coordination Primitive
**GStack hints at this. Nobody has systematized it.**

GStack's `/codex` cross-model review is the only framework that deliberately uses model diversity as a coordination tool. The Diversity Collapse paper proves this matters: homogeneous agents produce correlated, redundant outputs. Heterogeneous agents (different models, different prompts, different training data) produce genuinely diverse perspectives.

Your entire stack runs on Claude/Anthropic. That's a single-model monoculture. The fix:

- Route different agent roles to different model providers. The CEO Reviewer could run on Claude Opus. The Paranoid Reviewer could run on Gemini. The implementation agents could run on DeepSeek or Qwen for cost efficiency. The diversity isn't just cheaper, it's better.
- The regime classifier already gates specialist agents. Extend it to gate model selection: "For this task type, Claude produces better outcomes. For that task type, Gemini does." The meta-learner accumulates data on model-task fit.
- Cross-model verification: run the same BU through two different models and compare claim satisfaction. Disagreement signals either a hard problem (good, surface it) or a model weakness (good, learn it).

This is the one architectural change that requires no new infrastructure. The Pattern Engine's executor already supports model tiering (Haiku/Sonnet/Opus). Extending it to cross-provider routing (Claude/Gemini/DeepSeek) is a config change, not a code change.

---

## THE HONEST ANSWER: IS THIS "IT"?

Almost. But there are three things the landscape reveals that the previous scoping missed:

**1. A2A compatibility is non-negotiable.** The protocol has 50+ enterprise partners. It's becoming the HTTP of agent communication. Forge and Aiglos need A2A support or they're building a proprietary stack in a standards-based world. The good news: A2A is JSON-RPC over HTTP. The interception pattern is identical to existing HTTP interception in Aiglos. The intent graph can model A2A task delegations as behavioral claims. This is integration work, not architecture work.

**2. Aiglos as the A2A security layer is a massive new product surface.** This wasn't in the previous scoping because A2A wasn't in the frame. It is now. Every A2A message between agents is an attack vector. Nobody is building the security layer. Aiglos is 80% there by virtue of already having the threat taxonomy, the interception engine, and the signed attestation. The A2A interception surface is the fourth surface alongside MCP, HTTP, and subprocess. The T-rules apply directly.

**3. Model heterogeneity is free alpha.** The Diversity Collapse paper proves that homogeneous agent populations produce diminishing returns. Cross-model routing produces genuine diversity at the agent level. GStack's `/codex` pattern demonstrates this with one slash command. Systematizing it across the entire coordination stack turns a research insight into a structural advantage. The executor already supports model tiering. Extending to cross-provider routing is config, not code.

---

## THE REVISED BUILD PLAN

Adding the three new items to the previous 5-build plan:

| Priority | Build | Effort | Impact |
|---|---|---|---|
| 1 | A2A protocol support in Forge (task delegation as BU claims) | Hours | Table stakes for interoperability |
| 2 | A2A interception surface in Aiglos (fourth surface) | Hours | New product category, no competitors |
| 3 | Recovery routing event bus | Hours | Detection to recovery |
| 4 | Cross-model routing in Pattern Engine executor | Hours | Free diversity from Diversity Collapse paper |
| 5 | Agent proposal engine | Hours | Autonomous agent creation |
| 6 | Context router with Shapley-value contribution scoring | A day or two | Intelligent knowledge routing at scale |
| 7 | Coordination tournament variants | A day or two | Empirical strategy optimization |
| 8 | Coordination meta-learner | A couple days | Self-improving coordination |

**Revised composite coverage after all 8 builds: ~96%**

The remaining 4% is the emergent coordination discovery problem that nobody has solved and that may require fundamental research, not engineering. But even that 4% is bounded: the meta-learner discovers strategies within the space of known coordination patterns. Truly emergent strategies that don't fit any known pattern would require something closer to what the Stochastic Self-Organization paper describes: agents autonomously constructing novel communication structures without predefined templates. That's a research contribution, not a product build.

---

## THE PUNCHLINE

The landscape confirms the thesis. Here's the stack ranked by what matters:

**Paperclip** is the closest competitor. Org charts, budgets, heartbeats, dashboard. 55k stars. But no verification, no security, no learning. It's a project management tool for agents. It doesn't know if the agents are doing the right thing, doing it safely, or getting better at it.

**A2A** is infrastructure, not product. It needs a security layer (Aiglos), a verification layer (Forge), and a learning layer (the meta-learner). The protocol enables coordination. It doesn't ensure coordination is correct, safe, or improving.

**GStack** is productivity tooling, not autonomous coordination. Garry is impressive but he's the orchestrator. Remove Garry from the loop and GStack produces nothing.

**The academic frontier** (Stochastic Self-Organization, Diversity Collapse, Emergent Behaviors) is producing the theoretical foundations that your system can operationalize. They have the math. You have the production infrastructure to apply it.

The white space is not "can agents coordinate." That's solved at a basic level by everyone. The white space is three questions nobody else is answering:

1. **How do you know the coordination produced the right outcome?** (Forge)
2. **How do you know the coordination is secure?** (Aiglos)
3. **How does the coordination get better over time?** (The meta-learner)

Those three questions, answered together, are the Domingos problem. You have production-grade answers to the first two and an 88% answer to the third.

The final piece isn't a build. It's a framing decision. Forge + Aiglos + the 8 integration builds aren't three products. They're one platform: **the verified, secured, self-improving coordination layer for multi-agent systems.**

That's the thing Pedro Domingos says is worth a trillion dollars. And you're ~1,700 lines of integration code from having it.
